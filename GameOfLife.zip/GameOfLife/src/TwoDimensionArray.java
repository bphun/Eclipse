public class TwoDimensionArray {

	int[][] array;
	
	public TwoDimensionArray(int[][] array) {
		this.array = array;
	}
	
	public int[][] array() {
		return array;
	}
	
}
