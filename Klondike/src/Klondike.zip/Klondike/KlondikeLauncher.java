
public class KlondikeLauncher {

	public static void main(String[] args) {
		new KlondikeFrame().setVisible(true);
	}
}
